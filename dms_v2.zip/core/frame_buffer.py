from collections import deque

class FrameBuffer:
    def __init__(self, maxlen=120):
        self.buffer = deque(maxlen=maxlen)

    def push(self, frame):
        self.buffer.append(frame)

    def get_latest(self):
        return self.buffer[-1] if self.buffer else None