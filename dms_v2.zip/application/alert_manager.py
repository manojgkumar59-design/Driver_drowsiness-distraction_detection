import time
import winsound  # On Linux/Mac, replace with playsound or simpleaudio

class AlertManager:
    def __init__(self, cooldown=2.0):
        self.last_alert = 0
        self.cooldown = cooldown

    def trigger(self, state):
        now = time.time()

        if now - self.last_alert < self.cooldown:
            return

        if state == "DROWSY":
            self._beep(1000, 1000)

        elif state == "DISTRACTED":
            self._beep(800, 1000)

        elif state == "FATIGUED":
            self._beep(1200, 1000)

        elif state == "CRITICAL":
            for _ in range(3):
                self._beep(1500, 1000)

        self.last_alert = now

    def _beep(self, freq, duration):
        try:
            winsound.Beep(freq, duration)
        except:
            pass