import numpy as np
import cv2

LANDMARK_IDS = [1, 152, 33, 263, 61, 291]

MODEL_POINTS = np.array([
    (0.0, 0.0, 0.0),
    (0.0, -330.0, -65.0),
    (-225.0, 170.0, -135.0),
    (225.0, 170.0, -135.0),
    (-150.0, -150.0, -125.0),
    (150.0, -150.0, -125.0)
], dtype=np.float64)

class HeadPoseEstimator:
    def estimate(self, landmarks, frame_shape):
        h, w = frame_shape

        image_points = np.array([
            (landmarks[i].x * w, landmarks[i].y * h)
            for i in LANDMARK_IDS
        ], dtype="double")

        focal_length = w
        center = (w / 2, h / 2)

        camera_matrix = np.array([
            [focal_length, 0, center[0]],
            [0, focal_length, center[1]],
            [0, 0, 1]
        ])

        dist_coeffs = np.zeros((4, 1))

        success, rvec, tvec = cv2.solvePnP(
            MODEL_POINTS, image_points, camera_matrix, dist_coeffs
        )

        if not success:
            return 0, 0, 0

        rmat, _ = cv2.Rodrigues(rvec)
        angles, *_ = cv2.RQDecomp3x3(rmat)

        return angles  # pitch, yaw, roll