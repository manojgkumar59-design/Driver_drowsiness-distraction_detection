import numpy as np

class FusionEngine:
    def compute(self, features):
        ear = np.mean(features["ear"]) if features["ear"] else 0
        perclos = np.mean(features["perclos"]) if features["perclos"] else 0
        yaw = np.mean(features["yaw"]) if features["yaw"] else 0

        fatigue_score = (1 - ear) * 0.5 + perclos * 0.5
        attention_score = max(0, 1 - abs(yaw) / 30)

        return {
            "fatigue": fatigue_score,
            "attention": attention_score
        }