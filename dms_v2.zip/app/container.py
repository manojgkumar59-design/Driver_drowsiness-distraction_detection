from core.event_bus import EventBus
from core.frame_buffer import FrameBuffer
from core.feature_store import FeatureStore

from input.video_input import VideoInputManager
from app.config import Config

# Perception
from perception.face_tracker import FaceTracker
from perception.eye_analyzer import EyeAnalyzer
from perception.head_pose import HeadPoseEstimator
from perception.yawn_detector import YawnDetector

# Decision
from decision.fusion_engine import FusionEngine
from decision.state_engine import StateEngine
from decision.smoother import TemporalSmoother

# Application
from application.alert_manager import AlertManager
from application.overlay import OverlayRenderer
from application.logger import Logger


class Container:
    def __init__(self):
        self.config = Config

        # Core
        self.event_bus = EventBus()
        self.frame_buffer = FrameBuffer(Config.BUFFER_SIZE)
        self.feature_store = FeatureStore(Config.FEATURE_WINDOW)

        # Input (IP Webcam supported)
        self.video = VideoInputManager(Config.CAMERA_SOURCE)

        # Perception
        self.face = FaceTracker()
        self.eye = EyeAnalyzer()
        self.head = HeadPoseEstimator()
        self.yawn = YawnDetector()

        # Decision
        self.fusion = FusionEngine()
        self.state_engine = StateEngine(Config)
        self.smoother = TemporalSmoother()

        # Application
        self.alerts = AlertManager(Config.ALERT_COOLDOWN)
        self.overlay = OverlayRenderer()
        self.logger = Logger()

        # Runtime state
        self.last_state = "UNKNOWN"