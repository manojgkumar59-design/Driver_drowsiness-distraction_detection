from collections import deque

class TemporalSmoother:
    def __init__(self, size=10):
        self.buffer = deque(maxlen=size)

    def update(self, state):
        self.buffer.append(state)

    def get(self):
        if not self.buffer:
            return "UNKNOWN"
        return max(set(self.buffer), key=self.buffer.count)