import cv2
from app.container import Container


def main():
    container = Container()

    while True:
        frame = container.video.read()
        if frame is None:
            continue

        frame = cv2.resize(frame, (640, 480))
        container.frame_buffer.push(frame)

        landmarks, conf = container.face.process(frame)

        if landmarks:
            # --- Perception ---
            ear, blink, left, right = container.eye.compute(
                landmarks, frame.shape[:2]
            )

            pitch, yaw, roll = container.head.estimate(
                landmarks, frame.shape[:2]
            )

            yawn, mar = container.yawn.compute(
                landmarks, frame.shape[:2]
            )

            # --- Feature Extraction ---
            perclos = 1 if ear < container.config.EAR_THRESHOLD else 0

            container.feature_store.update(ear, perclos, yaw, yawn)

            # --- Decision ---
            features = container.feature_store.snapshot()
            fusion = container.fusion.compute(features)

            state = container.state_engine.evaluate(
                fusion,
                {
                    "yaw": yaw,
                    "perclos": perclos,
                    "yawn": yawn
                }
            )

            container.smoother.update(state)
            state = container.smoother.get()

            container.last_state = state

            # --- Application Layer ---
            container.alerts.trigger(state)
            container.logger.log(state, fusion)

            frame = container.overlay.draw(frame, {
                "state": state,
                "ear": ear,
                "perclos": perclos,
                "yaw": yaw
            })

        else:
            container.last_state = "NO_FACE"

        cv2.imshow("DMS v2 - IP Webcam Ready", frame)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cv2.destroyAllWindows()


if __name__ == "__main__":
    main()