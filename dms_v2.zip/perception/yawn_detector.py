import numpy as np

MOUTH = [13, 14, 78, 308]

class YawnDetector:
    def compute(self, landmarks, frame_shape):
        h, w = frame_shape

        pts = np.array([(landmarks[i].x * w, landmarks[i].y * h) for i in MOUTH])

        vertical = np.linalg.norm(pts[0] - pts[1])
        horizontal = np.linalg.norm(pts[2] - pts[3])

        mar = vertical / horizontal if horizontal != 0 else 0

        return mar > 0.6, mar