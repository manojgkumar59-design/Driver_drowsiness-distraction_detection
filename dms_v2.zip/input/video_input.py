import cv2
import time

class VideoInputManager:
    def __init__(self, source):
        self.source = source
        self.cap = None
        self.connect()

    def connect(self):
        self.cap = cv2.VideoCapture(self.source)
        if not self.cap.isOpened():
            raise RuntimeError("Camera connection failed")

    def read(self):
        ret, frame = self.cap.read()
        if not ret:
            self.cap.release()
            time.sleep(1)
            self.connect()
            return None
        return frame