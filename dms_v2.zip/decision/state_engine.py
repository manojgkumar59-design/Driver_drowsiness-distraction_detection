class StateEngine:
    def __init__(self, config):
        self.config = config

    def evaluate(self, fusion, raw):
        if raw["yaw"] > self.config.YAW_THRESHOLD:
            return "DISTRACTED"

        if raw["perclos"] > self.config.PERCLOS_THRESHOLD:
            return "DROWSY"

        if fusion["fatigue"] > 0.7:
            return "FATIGUED"

        return "AWAKE"