import logging

class Logger:
    def __init__(self):
        logging.basicConfig(
            filename="dms.log",
            level=logging.INFO,
            format="%(asctime)s - %(message)s"
        )

    def log(self, state, features):
        logging.info(f"STATE={state} FEATURES={features}")