import cv2

class OverlayRenderer:
    def draw(self, frame, data):
        color = (0, 255, 0)

        if data["state"] != "AWAKE":
            color = (0, 0, 255)

        cv2.putText(frame, f"State: {data['state']}", (10, 30),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)

        cv2.putText(frame, f"EAR: {data['ear']:.2f}", (10, 60),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        cv2.putText(frame, f"PERCLOS: {data['perclos']:.2f}", (10, 90),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        cv2.putText(frame, f"Yaw: {data['yaw']:.1f}", (10, 120),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 2)

        return frame