from collections import deque

class FeatureStore:
    def __init__(self, maxlen=60):
        self.ear = deque(maxlen=maxlen)
        self.perclos = deque(maxlen=maxlen)
        self.yaw = deque(maxlen=maxlen)

    def update(self, ear, perclos, yaw,yawn):
        self.ear.append(ear)
        self.perclos.append(perclos)
        self.yaw.append(yaw)
    
    def snapshot(self):
        return {
            "ear": list(self.ear),
            "perclos": list(self.perclos),
            "yaw": list(self.yaw)
        }