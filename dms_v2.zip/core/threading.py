import threading

class Worker(threading.Thread):
    def __init__(self, target):
        super().__init__()
        self.target = target
        self.daemon = True

    def run(self):
        self.target()