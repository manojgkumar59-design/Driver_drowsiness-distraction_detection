import numpy as np

LEFT_EYE = [33, 160, 158, 133, 153, 144]
RIGHT_EYE = [362, 385, 387, 263, 373, 380]

class EyeAnalyzer:
    def __init__(self):
        self.blink_counter = 0
        self.last_closed = False

    def _get_eye(self, landmarks, idxs, w, h):
        return np.array([(landmarks[i].x * w, landmarks[i].y * h) for i in idxs])

    def _ear(self, eye):
        A = np.linalg.norm(eye[1] - eye[5])
        B = np.linalg.norm(eye[2] - eye[4])
        C = np.linalg.norm(eye[0] - eye[3])
        return (A + B) / (2.0 * C) if C != 0 else 0

    def compute(self, landmarks, frame_shape):
        h, w = frame_shape
        left = self._get_eye(landmarks, LEFT_EYE, w, h)
        right = self._get_eye(landmarks, RIGHT_EYE, w, h)

        ear = (self._ear(left) + self._ear(right)) / 2.0

        blink = False
        if ear < 0.21:
            if not self.last_closed:
                blink = True
                self.blink_counter += 1
            self.last_closed = True
        else:
            self.last_closed = False

        return ear, blink, left, right